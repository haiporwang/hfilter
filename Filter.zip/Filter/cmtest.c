#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hash.h"
#include "cm.h"
#include "cmf.h"
// #include "stream.h"

#define MAX_INSERT_PACKAGE 32000000
#define THRESHLOD00 16
#define THRESHLOD01 750
#define THRESHLOD10 16
#define THRESHLOD11 750
#define THRESHLOD20 750

typedef struct
{
    char src_ip[8];
    char dst_ip[8];
    char src_port[8];
    char dst_port[8];
} stream_st;

char insert_data[MAX_INSERT_PACKAGE][8];
stream_st stream_data[MAX_INSERT_PACKAGE / 4];

void creat_sketch(stream_st stream, cmsketch_t *cms0, cmsketch_t *cms1, cmsketch_t *cms2, cmsketch_t *cms3, cmfilter_t *cmf0, cmfilter_t *cmf1, cmfilter_t *cmf2)
{
    //For cms0 layer1
    char line0[8 * 4];
    char line1[8];
    char line2[8];
    sprintf(line0, "%s%s%s%s", stream.src_ip, stream.src_port, stream.dst_ip, stream.dst_port);
    filter_add(cmf0, line0, (8 * 4), 1, 0);
    if (filter_count(cmf0, line0, (8 * 4), 1) > THRESHLOD00)
    {
        filter_add(cmf0, line0, (8 * 4), 1, 1);
        if (filter_count(cmf0, line0, (8 * 4), cmf0->d) > THRESHLOD01)
        {
            // CMS0
            sketch_add(cms0, line0, (8 * 4), 1);
        }
        else
        {
            sprintf(line1, "%s", stream.src_ip);
            filter_add(cmf1, line1, (8 * 4), 1, 0);
            if (filter_count(cmf1, line1, 8, 1) > THRESHLOD10)
            {
                filter_add(cmf1, line1, (8 * 4), 1, 1);
                if (filter_count(cmf1, line1, 8, cmf0->d) > THRESHLOD11)
                {
                    // CMS1
                    sketch_add(cms1, line1, 8, 1);
                }
                else
                {
                    sprintf(line2, "%s", stream.dst_ip);
                    filter_add(cmf2, line2, 8, 1, 0);
                    if (filter_count(cmf2, line2, 8, 1) > THRESHLOD20)
                    {
                        // CMS2
                        sketch_add(cms2, line2, 8, 1);
                    }
                    else
                    {
                        sketch_add(cms3, line2, 8, 1);
                    }
                }
            }
        }
    }
}

int load_data(const char *filename)
{
    FILE *pf = fopen(filename, "rb");
    if (!pf)
    {
        printf("%s%s", filename, " not found.");
        exit(-1);
    }

    char ip[8];
    int ret = 0;
    while (fread(ip, 1, 8, pf))
    {
        strcpy(insert_data[ret], ip);
        ret++;
        if (ret == MAX_INSERT_PACKAGE)
            break;
    }
    fclose(pf);

    int index = 0;
    int stream_count = 0;
    while ((index + 3) < ret)
    {
        strcpy(stream_data[index / 4].src_ip, insert_data[index]);
        strcpy(stream_data[index / 4].src_port, insert_data[index + 1]);
        strcpy(stream_data[index / 4].dst_ip, insert_data[index + 2]);
        strcpy(stream_data[index / 4].dst_port, insert_data[index + 3]);
        index += 4;
    }
    return ret;
}

int main(int argc, char const *argv[])
{
    /* code */

    int packet_num = load_data("data/sample.dat");
    cmsketch_t *cms0 = sketch_new(packet_num / 4, 2);
    cmsketch_t *cms1 = sketch_new(packet_num / 4, 2);
    cmsketch_t *cms2 = sketch_new(packet_num / 4, 2);
    cmsketch_t *cms3 = sketch_new(packet_num / 4, 2);

    cmfilter_t *cmf0 = filter_new(packet_num / 4, 2);
    cmfilter_t *cmf1 = filter_new(packet_num / 4, 2);
    cmfilter_t *cmf2 = filter_new(packet_num / 4, 2);
    for (int i = 0; i < (packet_num / 4); i++)
    {
        creat_sketch(stream_data[i], cms0, cms1, cms2, cms3, cmf0, cmf1, cmf2);
    }
    return 0;
}
