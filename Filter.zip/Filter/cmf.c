#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#include "cmf.h"
#include "hash.h"

/* allocate a new filter  with width w and depth d */
cmfilter_t *filter_new(int w, int d)
{

    cmfilter_t *cms = calloc(1, sizeof(cmfilter_t));

    cms->w = w;
    cms->d = d;

    cms->sk = calloc(d, sizeof(uint32_t *));
    for (int i = 0; i < d; i++)
    {
        cms->sk[i] = calloc(w, sizeof(uint32_t));
    }

    return cms;
}

void filter_free(cmfilter_t *cms)
{

    for (int i = 0; i < cms->d; i++)
    {
        free(cms->sk[i]);
    }

    free(cms->sk);

    free(cms);
}

void filter_add(cmfilter_t *cms, unsigned char *b, size_t len,
                uint32_t count, int layer)
{
    
    uint32_t h = 0;
    
    if (layer == 0) {
        h = leveldb_bloom_hash(b, len);
    }else{
        h = jenkins_hash(b, len);
    }
    int pos = h % cms->w;
    cms->sk[layer][pos] += count;

}

uint32_t filter_count(cmfilter_t *cms, unsigned char *b, size_t len,int layer)
{

    uint32_t h1 = leveldb_bloom_hash(b, len);
    uint32_t h2 = jenkins_hash(b, len);

    uint32_t min = UINT32_MAX;

    for (int i = 0; i < layer; i++)
    {
        int pos;
        if (i == 0) {
            pos = h1 % cms->w;
        }
        else {
            pos = h2 % cms->w;
        }
        if (cms->sk[i][pos] < min)
        {
            min = cms->sk[i][pos];
        }
    }

    return min;
}

cmfilter_t *filter_clone(cmfilter_t *cms)
{

    cmfilter_t *clone = filter_new(cms->w, cms->d);

    for (int i = 0; i < cms->d; i++)
    {
        memmove(clone->sk[i], cms->sk[i], cms->w * sizeof(uint32_t));
    }

    return clone;
}

void filter_merge(cmfilter_t *cms1, cmfilter_t *cms2)
{

    assert(cms1->w == cms2->w);
    assert(cms1->d == cms2->d);

    for (int d = 0; d < cms1->d; d++)
    {
        for (int w = 0; w < cms1->w; w++)
        {
            cms1->sk[d][w] += cms2->sk[d][w];
        }
    }
}

void filter_compress(cmfilter_t *cms)
{

    assert((cms->w & (cms->w - 1)) == 0);

    /* new width */
    cms->w /= 2;

    for (int d = 0; d < cms->d; d++)
    {
        uint32_t *row = calloc(cms->w, sizeof(uint32_t));
        for (int w = 0; w < cms->w; w++)
        {
            row[w] = cms->sk[d][w] + cms->sk[d][cms->w + w];
        }

        free(cms->sk[d]);
        cms->sk[d] = row;
    }
}

uint32_t *filter_values(cmfilter_t *cms, unsigned char *b, size_t len)
{

    uint32_t h1 = leveldb_bloom_hash(b, len);
    uint32_t h2 = jenkins_hash(b, len);

    uint32_t *vals = calloc(cms->d, sizeof(uint32_t));

    for (int i = 0; i < cms->d; i++)
    {
        int pos = (h1 + i * h2) % cms->w;
        vals[i] = cms->sk[i][pos];
    }

    return vals;
}
