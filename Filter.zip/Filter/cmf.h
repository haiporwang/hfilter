
#include <stddef.h>
#include <stdint.h>

typedef struct
{
    int w, d;
    uint32_t **sk;
} cmfilter_t;

void filter_add(cmfilter_t *cms, unsigned char *b, size_t len, uint32_t count, int layer);
cmfilter_t *filter_clone(cmfilter_t *cms);
void filter_compress(cmfilter_t *cms);
uint32_t filter_count(cmfilter_t *cms, unsigned char *b, size_t len, int layer);
void filter_free(cmfilter_t *cms);
void filter_merge(cmfilter_t *cms1, cmfilter_t *cms2);
cmfilter_t *filter_new(int w, int d);
uint32_t *filter_values(cmfilter_t *cms, unsigned char *b, size_t len);
